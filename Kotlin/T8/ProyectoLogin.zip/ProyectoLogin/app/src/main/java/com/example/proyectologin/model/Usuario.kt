package com.example.proyectologin.model

data class Usuario(var nombre:String, var correo:String, var password:String, var edad:String, var direccion:String): java.io.Serializable

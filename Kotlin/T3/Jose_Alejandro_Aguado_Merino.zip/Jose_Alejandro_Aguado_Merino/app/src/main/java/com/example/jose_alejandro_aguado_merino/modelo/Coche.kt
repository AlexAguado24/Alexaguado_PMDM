package com.example.jose_alejandro_aguado_merino.modelo

data class Coche(var nombre:String, var marca:String, var anio:Int, var combustible: String, var imagen: Int): java.io.Serializable

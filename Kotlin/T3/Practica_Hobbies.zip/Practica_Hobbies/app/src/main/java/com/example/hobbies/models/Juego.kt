package com.example.hobbies.models

class Juego(var imagenJuego: Int, var nombre: String, var tipo: String ) {
}
package com.example.hobbies.models

class Serie(var imagenSerie: Int, var nombre: String, var genero: String) {
}
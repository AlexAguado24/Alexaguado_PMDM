package com.example.hobbies.models

class Futbol(var imagenFutbol: Int,var nombre: String, var equipo: String){
}
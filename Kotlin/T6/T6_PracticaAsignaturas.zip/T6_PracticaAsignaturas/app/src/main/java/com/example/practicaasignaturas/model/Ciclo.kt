package com.example.practicaasignaturas.model

data class Ciclo(var nombre: String, var imagen: Int) {
}
package com.example.practicaasignaturas.model

data class Asignatura(var nombre: String, var siglas: String, var profesor: String, var horas: String, var ciclo:String, var curso: String): java.io.Serializable
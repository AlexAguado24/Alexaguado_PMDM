package com.example.examensegundaevaluacion.model

data class Vuelo(var nombre:String, var imagen:Int)
package com.example.t5_ejerciciorecycler.model

data class Usuario (var nombre: String, var apellido:String, var edad: String, var puesto:String ): java.io.Serializable{
}
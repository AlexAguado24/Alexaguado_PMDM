package model

class Puntuacion (var jugador: Jugador) {


}